Venky Billing App - Minimal React project
-----------------------------------------

Contents:
- package.json (Vite)
- src/App.jsx (Billing UI)
- public/index.html

How to run (web):
1. Install Node.js (14+)
2. npm install
3. npm run dev

To make Android APK (Capacitor):
1. npm run build
2. npm install @capacitor/core @capacitor/cli --save
3. npx cap init venky.billing.app com.venky.billing
4. npx cap add android
5. npx cap copy android
6. Open android project in Android Studio: npx cap open android
7. Build APK from Android Studio (recommended) or use ./gradlew assembleRelease

Notes:
- This is a minimal starter. Replace supplier/buyer details in src/App.jsx or expand features.
- For e-invoice IRN generation you need to integrate government APIs (outside scope).
