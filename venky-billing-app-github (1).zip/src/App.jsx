import React, { useState, useRef, useEffect } from "react";
import QRCode from "qrcode.react";

/* Minimal Billing App adapted from provided design.
   Edit supplier/buyer details, add items, save to localStorage.
   Use `npm run build` then wrap with Capacitor to make Android APK.
*/

export default function App() {
  const [supplier, setSupplier] = useState({
    name: "SRI SRI VENKATESWARA ENTERPRISES",
    address: "D.No:2-34, DASARIPALEM, CHOWDAVARAM VILLAGE, SURVEY NO.114/C, HAMLET OF CHOWDAVARAM",
    gstin: "37BLAPS3996M2Z7",
    stateCode: "37",
    email: "srisrivenkateswara7@gmail.com",
  });

  const [consignee, setConsignee] = useState({
    name: "APSCSCL LTD",
    address: "THE DISTRICT MANAGER, BHIMAVARAM, WEST GODAVARI DISTRICT",
    gstin: "37AABCA7164R2Z1",
  });

  const [buyer, setBuyer] = useState({
    name: "A P STATE CIVIL SUPPLIES CORPORATION LTD",
    address: "4TH & 5TH FLOOR, 10-152/1, SRI SAI TOWERS, VIJAYAWADA",
    gstin: "37AABCA7164R2Z1",
  });

  const [invoiceMeta, setInvoiceMeta] = useState({
    invoiceNo: "SSVE/375",
    date: new Date().toISOString().slice(0, 10),
    irn: "",
    ackNo: "",
    ackDate: "",
  });

  const [items, setItems] = useState([
    {
      desc: "RICE PACKING",
      hsn: "998898",
      qty: 238.05,
      unit: "TON",
      rateExclTax: 2717.71,
      rateInclTax: 2853.6,
      amount: 646950.87,
    },
  ]);

  const [cgstRate, setCgstRate] = useState(2.5);
  const [sgstRate, setSgstRate] = useState(2.5);
  const [discount, setDiscount] = useState(0);
  const [transport, setTransport] = useState(0);

  const invoiceRef = useRef();

  useEffect(() => {
    const saved = localStorage.getItem("venky_invoices_v1");
    if (saved) {
      // no-op for now
    }
  }, []);

  function updateItem(idx, key, value) {
    const next = items.map((it, i) => (i === idx ? { ...it, [key]: value } : it));
    next.forEach((it) => (it.amount = (Number(it.qty) || 0) * (Number(it.rateExclTax) || 0)));
    setItems(next);
  }

  function addItem() {
    setItems([...items, { desc: "", hsn: "", qty: 0, unit: "NOS", rateExclTax: 0, rateInclTax: 0, amount: 0 }]);
  }

  function removeItem(i) {
    const n = items.filter((_, idx) => idx !== i);
    setItems(n.length ? n : [{ desc: "", hsn: "", qty: 0, unit: "NOS", rateExclTax: 0, rateInclTax: 0, amount: 0 }]);
  }

  const subtotal = items.reduce((s, it) => s + (Number(it.amount) || 0), 0);
  const gstAmount = ((subtotal - Number(discount) || 0) * (Number(cgstRate) + Number(sgstRate))) / 100;
  const total = subtotal - Number(discount) + gstAmount + Number(transport || 0);

  function saveInvoice() {
    const id = "INV-" + Date.now();
    const invoice = { id, date: new Date().toISOString(), supplier, consignee, buyer, items, subtotal, gstAmount, total, invoiceMeta };
    const saved = JSON.parse(localStorage.getItem("venky_invoices_v1") || "[]");
    saved.unshift(invoice);
    localStorage.setItem("venky_invoices_v1", JSON.stringify(saved));
    alert("Saved " + id);
  }

  function amountInWords(n) {
    // very small helper: only returns rupees in words for integers up to crores (simple)
    const num = Math.round(Number(n) || 0);
    if (!num) return "Zero";
    // This is a placeholder to keep bundle small.
    return num + " (in words)";
  }

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', background: '#fff', padding: 16 }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Tax Invoice - Venky Billing</h1>
        <div>
          <button onClick={saveInvoice}>Save</button>
        </div>
      </header>

      <section style={{ display: 'flex', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <h3>Supplier / Seller</h3>
          <div><strong>{supplier.name}</strong></div>
          <div style={{ fontSize: 12 }}>{supplier.address}</div>
          <div>GSTIN: {supplier.gstin} | State Code: {supplier.stateCode}</div>
          <div>Email: {supplier.email}</div>

          <h4 style={{ marginTop: 12 }}>Consignee</h4>
          <div><strong>{consignee.name}</strong></div>
          <div style={{ fontSize: 12 }}>{consignee.address}</div>
          <div>GSTIN: {consignee.gstin}</div>
        </div>

        <div style={{ width: 260 }}>
          <div>Invoice #: <strong>{invoiceMeta.invoiceNo}</strong></div>
          <div>Date: {invoiceMeta.date}</div>
          <div>IRN: <input value={invoiceMeta.irn} onChange={e => setInvoiceMeta({...invoiceMeta, irn: e.target.value})} style={{width: '100%'}}/></div>
          <div style={{ marginTop: 8 }}>
            <QRCode value={invoiceMeta.irn || invoiceMeta.invoiceNo} size={120} />
          </div>
        </div>
      </section>

      <section style={{ marginTop: 16 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th style={{ border: '1px solid #ccc' }}>Sl</th>
              <th style={{ border: '1px solid #ccc' }}>Description</th>
              <th style={{ border: '1px solid #ccc' }}>HSN</th>
              <th style={{ border: '1px solid #ccc' }}>Qty</th>
              <th style={{ border: '1px solid #ccc' }}>Rate (Excl)</th>
              <th style={{ border: '1px solid #ccc' }}>Amount</th>
              <th style={{ border: '1px solid #ccc' }}>Action</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, i) => (
              <tr key={i}>
                <td style={{ border: '1px solid #eee', textAlign: 'center' }}>{i+1}</td>
                <td style={{ border: '1px solid #eee' }}><input value={it.desc} onChange={e=> updateItem(i,'desc', e.target.value)} /></td>
                <td style={{ border: '1px solid #eee' }}><input value={it.hsn} onChange={e=> updateItem(i,'hsn', e.target.value)} /></td>
                <td style={{ border: '1px solid #eee' }}><input type="number" value={it.qty} onChange={e=> updateItem(i,'qty', Number(e.target.value))} /></td>
                <td style={{ border: '1px solid #eee' }}><input type="number" value={it.rateExclTax} onChange={e=> updateItem(i,'rateExclTax', Number(e.target.value))} /></td>
                <td style={{ border: '1px solid #eee', textAlign: 'right' }}>{(Number(it.amount)||0).toFixed(2)}</td>
                <td style={{ border: '1px solid #eee' }}><button onClick={()=> removeItem(i)}>Remove</button></td>
              </tr>
            ))}
          </tbody>
        </table>
        <div style={{ marginTop: 8 }}>
          <button onClick={addItem}>Add Item</button>
        </div>
      </section>

      <section style={{ marginTop: 12, textAlign: 'right' }}>
        <div>Subtotal: ₹ {subtotal.toFixed(2)}</div>
        <div>GST: ₹ {gstAmount.toFixed(2)} ({cgstRate}% + {sgstRate}%)</div>
        <div>Transport: ₹ <input type="number" value={transport} onChange={e=> setTransport(Number(e.target.value))} style={{width:80}} /></div>
        <div style={{ fontWeight: 'bold', marginTop: 8 }}>Total: ₹ {total.toFixed(2)}</div>
        <div style={{ fontSize: 12 }}>Amount (in words): {amountInWords(total)}</div>
      </section>
    </div>
  );
}
